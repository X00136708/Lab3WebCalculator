function rename(name){
    document.getElementById("lab3").innerHTML = name;
    return name;
}
function getValue(){
    var form = document.getElementById("inputA").value;
    return form;
}
function display(){
    console.log(document.getElementById("inputA").value);
}
function displayOnPage(){
    return document.getElementById('print').innerHTML = document.getElementById("inputA").value;
    
}
function loop(){
    for(let i = 0; i < 10; i++){
        console.log(document.getElementsByTagName("p")[i]);
    }
}

function calc(val){
    var num1 = document.getElementById("numA").value;
    var num2 = document.getElementById("numB").value;
    if(val=="add"){
        return document.getElementById('answer').innerHTML = parseInt(num1) + parseInt(num2); 
    }
    else if(val=='sub'){
        return document.getElementById('answer').innerHTML = (num1 - num2); 
    }
    else if(val=='mul'){
        return document.getElementById('answer').innerHTML = (num1 * num2); 
    }
    else if(val=='div'){
        return document.getElementById('answer').innerHTML = (num1 / num2); 
    }
}